salt.modules.freebsd_update module
==================================

.. automodule:: salt.modules.freebsd_update
    :members:
    :undoc-members:
