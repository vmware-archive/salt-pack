.. _all-salt.beacons:

==============
beacon modules
==============

.. currentmodule:: salt.beacons

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    adb
    btmp
    diskusage
    glxinfo
    inotify
    journald
    load
    memusage
    network_info
    network_settings
    pkg
    proxy_example
    ps
    salt_proxy
    service
    sh
    twilio_txt_msg
    wtmp
