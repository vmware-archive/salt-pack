"""
asynchronous (nonblocking) windows  io package

"""

from .wining import WinMailslotNb, PeerWms
