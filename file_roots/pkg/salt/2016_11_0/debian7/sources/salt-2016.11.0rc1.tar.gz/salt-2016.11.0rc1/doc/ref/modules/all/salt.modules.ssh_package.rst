salt.modules.ssh_package module
===============================

.. automodule:: salt.modules.ssh_package
    :members:
