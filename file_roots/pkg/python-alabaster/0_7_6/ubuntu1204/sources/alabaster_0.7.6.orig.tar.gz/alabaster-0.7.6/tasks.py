from invoke import Collection
from invocations.packaging import release


ns = Collection(release)
