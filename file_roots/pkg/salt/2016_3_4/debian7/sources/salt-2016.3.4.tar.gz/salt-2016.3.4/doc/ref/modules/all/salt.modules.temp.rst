=================
salt.modules.temp
=================

.. automodule:: salt.modules.temp
    :members:
