salt.modules.apk module
=======================

.. automodule:: salt.modules.apk
    :members:
    :undoc-members:
