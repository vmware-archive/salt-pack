========================
Python 2.5 Compatibility
========================

.. automodule:: kitchen.pycompat25

.. automodule:: kitchen.pycompat25.collections._defaultdict

