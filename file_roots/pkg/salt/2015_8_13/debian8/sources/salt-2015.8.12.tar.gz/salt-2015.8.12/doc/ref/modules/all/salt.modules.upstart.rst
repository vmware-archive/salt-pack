====================
salt.modules.upstart
====================

.. automodule:: salt.modules.upstart
    :members: