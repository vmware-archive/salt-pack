=================
salt.beacons.load
=================

.. automodule:: salt.beacons.load
    :members: