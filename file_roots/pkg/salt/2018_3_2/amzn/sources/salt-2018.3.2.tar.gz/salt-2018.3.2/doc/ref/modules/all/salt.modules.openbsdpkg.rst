=======================
salt.modules.openbsdpkg
=======================

.. automodule:: salt.modules.openbsdpkg
    :members:
    :exclude-members: available_version