=====================
salt.modules.win_repo
=====================

.. automodule:: salt.modules.win_repo
    :members: