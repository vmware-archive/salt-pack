salt.modules.boto3_route53 module
=================================

.. automodule:: salt.modules.boto3_route53
    :members:
    :undoc-members:
