#include <stdlib.h>
#include <string.h>

typedef int int32_t;
typedef unsigned int uint32_t;
