#!/bin/sh
cd openpgm/pgm
autoreconf -i -f
