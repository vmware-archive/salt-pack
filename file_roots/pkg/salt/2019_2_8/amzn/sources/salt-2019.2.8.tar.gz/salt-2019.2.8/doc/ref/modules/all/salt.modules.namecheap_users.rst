salt.modules.namecheap_users module
===================================

.. automodule:: salt.modules.namecheap_users
    :members:
    :undoc-members:
