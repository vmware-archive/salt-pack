===================
salt.modules.aixpkg
===================

.. automodule:: salt.modules.aixpkg
    :members:
    :undoc-members:
