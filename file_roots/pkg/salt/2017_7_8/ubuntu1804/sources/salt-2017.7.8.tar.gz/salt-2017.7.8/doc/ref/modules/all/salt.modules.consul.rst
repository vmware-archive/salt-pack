===================
salt.modules.consul
===================

.. automodule:: salt.modules.consul
    :members:
