=========================
salt.modules.freebsdports
=========================

.. automodule:: salt.modules.freebsdports
    :members: