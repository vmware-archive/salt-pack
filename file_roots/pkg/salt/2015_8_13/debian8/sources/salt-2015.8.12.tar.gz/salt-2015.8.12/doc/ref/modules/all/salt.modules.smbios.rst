===================
salt.modules.smbios
===================

.. automodule:: salt.modules.smbios
    :members: