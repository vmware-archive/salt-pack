==========================
salt.engines.ircbot
==========================

.. automodule:: salt.engines.ircbot
    :members:
