.. _all-salt.cache:

=============
cache modules
=============

.. currentmodule:: salt.cache

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    localfs
    consul
    redis_cache
