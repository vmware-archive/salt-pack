===================
salt.output.compact
===================

.. automodule:: salt.output.compact
    :members:
