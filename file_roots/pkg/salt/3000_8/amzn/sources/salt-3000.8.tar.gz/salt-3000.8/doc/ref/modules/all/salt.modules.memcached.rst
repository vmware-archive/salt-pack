======================
salt.modules.memcached
======================

.. automodule:: salt.modules.memcached
    :members:
    :exclude-members: incr, decr