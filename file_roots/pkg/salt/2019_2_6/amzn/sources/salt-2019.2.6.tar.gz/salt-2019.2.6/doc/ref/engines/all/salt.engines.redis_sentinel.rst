salt.engines.redis_sentinel module
==================================

.. automodule:: salt.engines.redis_sentinel
    :members:
