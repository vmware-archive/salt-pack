salt.modules.inspectlib.entities module
=======================================

.. automodule:: salt.modules.inspectlib.entities
    :members:
    :undoc-members:
