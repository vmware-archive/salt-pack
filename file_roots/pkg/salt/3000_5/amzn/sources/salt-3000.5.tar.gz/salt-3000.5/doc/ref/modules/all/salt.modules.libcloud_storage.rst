salt.modules.libcloud_storage
=============================

.. automodule:: salt.modules.libcloud_storage
    :members:
    :undoc-members:
