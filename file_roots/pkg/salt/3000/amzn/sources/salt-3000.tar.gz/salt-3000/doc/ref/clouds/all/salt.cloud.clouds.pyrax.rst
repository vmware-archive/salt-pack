=======================
salt.cloud.clouds.pyrax
=======================

.. automodule:: salt.cloud.clouds.pyrax
    :members: