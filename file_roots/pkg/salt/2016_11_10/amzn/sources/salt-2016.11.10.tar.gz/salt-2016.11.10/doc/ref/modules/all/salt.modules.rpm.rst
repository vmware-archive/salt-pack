================
salt.modules.rpm
================

.. automodule:: salt.modules.rpm
    :members: