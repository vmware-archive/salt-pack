salt.modules.mac_shadow module
==============================

.. automodule:: salt.modules.mac_shadow
    :members:
