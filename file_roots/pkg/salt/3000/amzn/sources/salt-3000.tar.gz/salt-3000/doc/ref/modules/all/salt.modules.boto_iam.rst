=====================
salt.modules.boto_iam
=====================

.. automodule:: salt.modules.boto_iam
    :members: