# -*- coding: utf-8 -*-
'''
    :codeauthor: :email:`Pedro Algarvio (pedro@algarvio.me)`

    salt.config.schemas
    ~~~~~~~~~~~~~~~~~~~

    Salt configuration related schemas for future validation
'''
