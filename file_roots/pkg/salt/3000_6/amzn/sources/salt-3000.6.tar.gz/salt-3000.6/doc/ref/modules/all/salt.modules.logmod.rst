salt.modules.logmod module
==========================

.. automodule:: salt.modules.logmod
    :members:
