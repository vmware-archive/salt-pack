============================
salt.modules.bluez_bluetooth
============================

.. automodule:: salt.modules.bluez_bluetooth
    :members:
