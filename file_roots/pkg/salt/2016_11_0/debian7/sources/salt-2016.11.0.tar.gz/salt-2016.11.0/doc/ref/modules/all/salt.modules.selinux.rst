====================
salt.modules.selinux
====================

.. automodule:: salt.modules.selinux
    :members: