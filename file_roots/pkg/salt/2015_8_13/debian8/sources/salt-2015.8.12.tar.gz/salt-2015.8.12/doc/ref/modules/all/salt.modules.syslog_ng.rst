======================
salt.modules.syslog_ng
======================

.. automodule:: salt.modules.syslog_ng
    :members: