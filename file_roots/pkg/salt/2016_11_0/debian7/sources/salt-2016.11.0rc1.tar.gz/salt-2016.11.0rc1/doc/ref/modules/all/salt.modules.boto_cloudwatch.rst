============================
salt.modules.boto_cloudwatch
============================

.. automodule:: salt.modules.boto_cloudwatch
    :members: