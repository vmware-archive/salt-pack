"""
Base classes for building higher layer custom async io protocols

"""
