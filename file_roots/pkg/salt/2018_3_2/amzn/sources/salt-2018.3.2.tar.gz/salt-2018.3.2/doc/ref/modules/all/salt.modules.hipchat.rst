====================
salt.modules.hipchat
====================

.. automodule:: salt.modules.hipchat
    :members:
