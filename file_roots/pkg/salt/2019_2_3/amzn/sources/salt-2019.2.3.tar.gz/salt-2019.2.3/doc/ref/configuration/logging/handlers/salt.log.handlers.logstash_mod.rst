==============================
salt.log.handlers.logstash_mod
==============================

.. automodule:: salt.log.handlers.logstash_mod
