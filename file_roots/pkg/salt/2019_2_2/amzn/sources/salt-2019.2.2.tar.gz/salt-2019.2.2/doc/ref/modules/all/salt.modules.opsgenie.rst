=====================
salt.modules.opsgenie
=====================

.. automodule:: salt.modules.opsgenie
    :members:
