decorators
==========


Module: :mod:`zmq.decorators`
-----------------------------

.. automodule:: zmq.decorators

.. currentmodule:: zmq.decorators


Decorators
----------

.. autofunction:: zmq.decorators.context

.. autofunction:: zmq.decorators.socket

