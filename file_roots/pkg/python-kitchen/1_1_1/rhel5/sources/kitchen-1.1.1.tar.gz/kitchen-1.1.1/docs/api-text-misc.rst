.. automodule:: kitchen.text.misc
    :members:
