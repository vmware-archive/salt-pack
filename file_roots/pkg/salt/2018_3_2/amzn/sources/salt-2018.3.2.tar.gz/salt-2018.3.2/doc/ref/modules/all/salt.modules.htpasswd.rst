=====================
salt.modules.htpasswd
=====================

.. automodule:: salt.modules.htpasswd
    :members: