========================
salt.cloud.clouds.vmware
========================

.. automodule:: salt.cloud.clouds.vmware
    :members:
    :exclude-members: get_configured_provider, get_dependencies, script
