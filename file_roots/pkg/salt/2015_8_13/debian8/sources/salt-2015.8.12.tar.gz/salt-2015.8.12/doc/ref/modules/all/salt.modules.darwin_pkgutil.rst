===========================
salt.modules.darwin_pkgutil
===========================

.. automodule:: salt.modules.darwin_pkgutil
    :members:
