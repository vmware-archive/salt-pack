salt.modules.mac_xattr module
=============================

.. automodule:: salt.modules.mac_xattr
    :members:
