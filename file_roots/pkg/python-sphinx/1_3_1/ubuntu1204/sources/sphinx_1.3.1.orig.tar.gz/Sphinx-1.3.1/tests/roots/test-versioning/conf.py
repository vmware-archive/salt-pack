project = 'versioning test root'
master_doc = 'index'
source_suffix = '.txt'
