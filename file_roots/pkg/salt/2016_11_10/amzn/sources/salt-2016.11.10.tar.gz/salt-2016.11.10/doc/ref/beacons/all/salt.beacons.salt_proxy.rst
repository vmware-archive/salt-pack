salt.beacons.salt_proxy module
==============================

.. automodule:: salt.beacons.salt_proxy
    :members:
