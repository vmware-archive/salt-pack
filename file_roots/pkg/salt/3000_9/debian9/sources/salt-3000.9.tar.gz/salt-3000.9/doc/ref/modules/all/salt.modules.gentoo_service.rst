===========================
salt.modules.gentoo_service
===========================

.. automodule:: salt.modules.gentoo_service
    :members: