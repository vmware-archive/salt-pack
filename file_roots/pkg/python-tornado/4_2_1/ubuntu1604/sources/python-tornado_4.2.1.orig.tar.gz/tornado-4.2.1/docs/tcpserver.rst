``tornado.tcpserver`` --- Basic `.IOStream`-based TCP server
============================================================

.. automodule:: tornado.tcpserver
    :members:
