==================
salt.modules.splay
==================

.. automodule:: salt.modules.splay
    :members:
