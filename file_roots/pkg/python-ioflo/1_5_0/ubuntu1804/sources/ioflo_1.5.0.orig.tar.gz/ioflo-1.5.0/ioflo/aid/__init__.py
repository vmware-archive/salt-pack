"""
aid package

helper and utility modules
"""
# frequent imports
from .odicting import odict, lodict, modict
from .osetting import oset
from .consoling import getConsole

