salt.modules.pushbullet module
==============================

.. automodule:: salt.modules.pushbullet
    :members:
