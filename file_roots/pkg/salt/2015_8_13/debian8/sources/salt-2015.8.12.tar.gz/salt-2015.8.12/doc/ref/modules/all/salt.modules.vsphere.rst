====================
salt.modules.vsphere
====================

.. automodule:: salt.modules.vsphere
    :members: