.. AUTO-GENERATED FILE -- DO NOT EDIT!

eventloop.ioloop
================

Module: :mod:`eventloop.ioloop`
-------------------------------
.. automodule:: zmq.eventloop.ioloop

.. currentmodule:: zmq.eventloop.ioloop

Classes
-------

:class:`DelayedCallback`
~~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: DelayedCallback
  :members:
  :undoc-members:
  :inherited-members:


:class:`ZMQIOLoop`
~~~~~~~~~~~~~~~~~~


.. autoclass:: ZMQIOLoop
  :members:
  :undoc-members:
  :inherited-members:


:class:`ZMQPoller`
~~~~~~~~~~~~~~~~~~


.. autoclass:: ZMQPoller
  :members:
  :undoc-members:
  :inherited-members:


Function
--------


.. autofunction:: zmq.eventloop.ioloop.install

