salt.modules.napalm_users module
================================

.. automodule:: salt.modules.napalm_users
    :members:
    :undoc-members:
