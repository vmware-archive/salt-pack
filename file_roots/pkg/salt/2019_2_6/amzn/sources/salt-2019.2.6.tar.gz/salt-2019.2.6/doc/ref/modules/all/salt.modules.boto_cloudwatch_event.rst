salt.modules.boto_cloudwatch_event module
=========================================

.. automodule:: salt.modules.boto_cloudwatch_event
    :members:
    :undoc-members:
