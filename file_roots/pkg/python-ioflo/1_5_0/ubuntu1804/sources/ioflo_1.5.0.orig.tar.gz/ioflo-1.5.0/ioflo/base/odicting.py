# for backwards compatibility. In future import from ..aid.odicting

from ..aid.odicting import odict, lodict

