====================================
salt.modules.openbsdrcctl_service.py
====================================

.. automodule:: salt.modules.openbsdrcctl_service
    :members:
