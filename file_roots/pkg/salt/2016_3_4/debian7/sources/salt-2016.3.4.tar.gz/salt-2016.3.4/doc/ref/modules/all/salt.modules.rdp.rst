================
salt.modules.rdp
================

.. automodule:: salt.modules.rdp
    :members: