=================
salt.modules.solr
=================

.. automodule:: salt.modules.solr
    :members: