===================
salt.modules.nagios
===================

.. automodule:: salt.modules.nagios
    :members: