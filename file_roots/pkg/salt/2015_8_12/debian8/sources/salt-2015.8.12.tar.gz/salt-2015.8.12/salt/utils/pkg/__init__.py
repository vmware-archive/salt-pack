# -*- coding: utf-8 -*-
'''
Helper modules used by lowpkg modules
'''
