=================
salt.modules.file
=================

.. automodule:: salt.modules.file
    :members:
    :exclude-members: list_backup, remove_backup