=====================
salt.modules.saltutil
=====================

.. automodule:: salt.modules.saltutil
    :members:
    :exclude-members: pillar_refresh
