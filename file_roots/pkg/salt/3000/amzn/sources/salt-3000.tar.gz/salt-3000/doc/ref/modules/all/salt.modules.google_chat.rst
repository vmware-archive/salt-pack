========================
salt.modules.google_chat
========================

.. automodule:: salt.modules.google_chat
    :members:
