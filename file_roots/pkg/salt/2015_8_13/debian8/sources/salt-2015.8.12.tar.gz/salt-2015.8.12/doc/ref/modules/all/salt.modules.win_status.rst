=======================
salt.modules.win_status
=======================

.. automodule:: salt.modules.win_status
    :members: