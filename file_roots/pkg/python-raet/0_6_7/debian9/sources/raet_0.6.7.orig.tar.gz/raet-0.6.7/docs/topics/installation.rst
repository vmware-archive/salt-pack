============
Installation
============

Current RAET is provided as a PyPi package.

To install on a UNIX based system use pip:

.. code-block:: bash

    $ pip install raet

On OS X:

.. code-block:: bash

    $ sudo pip install raet
