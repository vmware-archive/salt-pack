============================
salt.log.handlers.sentry_mod
============================

.. automodule:: salt.log.handlers.sentry_mod
