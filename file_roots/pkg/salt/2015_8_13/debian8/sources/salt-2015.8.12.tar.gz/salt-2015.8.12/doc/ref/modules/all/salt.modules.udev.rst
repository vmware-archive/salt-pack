=================
salt.modules.udev
=================

.. automodule:: salt.modules.udev
    :members:
