====================
salt.modules.ldapmod
====================

.. automodule:: salt.modules.ldapmod
    :members: