===================
salt.modules.sysmod
===================

.. automodule:: salt.modules.sysmod
    :members: