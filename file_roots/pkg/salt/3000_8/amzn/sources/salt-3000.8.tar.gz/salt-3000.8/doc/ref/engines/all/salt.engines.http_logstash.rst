==========================
salt.engines.http_logstash
==========================

.. automodule:: salt.engines.http_logstash
    :members:
