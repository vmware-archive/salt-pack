=========================
salt.modules.openbsdrcctl
=========================

.. automodule:: salt.modules.openbsdrcctl
    :members:
