======================
salt.modules.telemetry
======================

.. automodule:: salt.modules.telemetry
    :members: