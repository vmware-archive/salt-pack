salt.modules.napalm_route module
================================

.. automodule:: salt.modules.napalm_route
    :members:
    :undoc-members:

