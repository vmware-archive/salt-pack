=================
salt.modules.sudo
=================

.. automodule:: salt.modules.sudo
    :members: