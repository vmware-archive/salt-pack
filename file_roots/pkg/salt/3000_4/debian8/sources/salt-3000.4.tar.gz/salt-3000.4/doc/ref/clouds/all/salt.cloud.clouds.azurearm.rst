==========================
salt.cloud.clouds.azurearm
==========================

.. automodule:: salt.cloud.clouds.azurearm
    :members:
