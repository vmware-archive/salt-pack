==================
salt.modules.cabal
==================

.. automodule:: salt.modules.cabal
    :members: